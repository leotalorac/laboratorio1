/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alopaisa;

/**
 *
 * @author lotalorafox
 */
public class Fecha {
    public int dia;
    public int mes;
    public int year;
    
    Fecha(int d,int m,int y){
        this.dia = d;
        this.mes = m;
        this.year = y;
    }
    Fecha(){}
}
