/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package alopaisa;
import java.util.Scanner;
/**
 *
 * @author lotalorafox
 */
public class Contabilidad {
    private Scanner sc = new Scanner(System.in);
    private float totalCredito;
    private float totalDevito;
    private float totalNeto;
    private Gasto g[] = new Gasto[1000];
    private Ingreso in[] = new Ingreso[1000];
    
    public Contabilidad(){
        totalCredito =0;
        totalDevito=0;
        totalNeto=0;
    }
    
    public void CrearGasto(Fecha f1,int gi,int n){
        
        
        for (int i = gi; i < n; i++) {
            g[i] = new Gasto(f1);
           System.out.println("Ingresa el nombre del gasto:");
           String de = sc.next();
           g[i].setDescripcion(de);
           System.out.println("Ingresa el valor del gasto:");
           int v = sc.nextInt();
           g[i].setValor(v);
           this.totalDevito+=g[i].getValor();
        }
        this.calctotal();
            
        
    }
    public void CrearIngreso(Fecha f1,int gi,int n){
        for (int i = gi; i < n; i++) {
           in[i] = new Ingreso(f1);
           System.out.println("Ingresa el nombre del ingreso:");
           String de = sc.next();
           in[i].setDescripcion(de);
           System.out.println("Ingresa el valor del ingreso:");
           int v = sc.nextInt();
           in[i].setValor(v);
           this.totalCredito+=in[i].getValor();
        }
        this.calctotal();
    }
    
    public void calctotal(){
        this.totalNeto = this.totalCredito - this.totalDevito;
    }

    public float getTotalCredito() {
        return totalCredito;
    }

    public float getTotalDevito() {
        return totalDevito;
    }

    public float getTotalNeto() {
        return totalNeto;
    }
    
    
    
    
    
}
